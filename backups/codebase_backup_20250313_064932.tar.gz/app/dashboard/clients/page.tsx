"use client"

import { useState, useEffect } from "react"
import { useSearchParams, useRouter } from "next/navigation"
import { ClientList } from "@/components/clients/client-list"
import { 
  Dialog, DialogContent, DialogDescription, 
  DialogFooter, DialogHeader, DialogTitle 
} from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { toast } from "@/components/ui/use-toast"
import { fetchClients, saveClient, deleteClient } from "@/lib/api"
import type { Client } from "@/lib/types"
import { Plus } from "lucide-react"

export default function ClientsPage() {
  const searchParams = useSearchParams()
  const router = useRouter()
  
  const editParam = searchParams.get('edit')
  
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false)
  const [currentClient, setCurrentClient] = useState<Client | null>(null)
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false)
  const [newClientName, setNewClientName] = useState("")
  
  // Handle URL parameters
  useEffect(() => {
    // If edit param is present, load the client for editing
    if (editParam) {
      const loadClient = async () => {
        try {
          const clients = await fetchClients()
          const clientToEdit = clients.find(c => c.id === editParam)
          if (clientToEdit) {
            setCurrentClient(clientToEdit)
            setIsEditDialogOpen(true)
          }
        } catch (error) {
          console.error("Error loading client for editing:", error)
        }
      }
      
      loadClient()
    }
  }, [editParam])
  
  const handleEditClient = async () => {
    if (!currentClient || !currentClient.name.trim()) {
      toast({
        title: "Error",
        description: "Client name cannot be empty",
        variant: "destructive",
      })
      return
    }

    try {
      await saveClient(currentClient)
      setIsEditDialogOpen(false)
      toast({
        title: "Success",
        description: "Client updated successfully",
      })
      
      // Clear URL parameters and refresh the page
      router.push('/dashboard/clients')
      router.refresh()
    } catch (error) {
      console.error("Error updating client:", error)
      toast({
        title: "Error",
        description: "Failed to update client",
        variant: "destructive",
      })
    }
  }
  
  const handleAddClient = async () => {
    if (!newClientName.trim()) {
      toast({
        title: "Error",
        description: "Client name cannot be empty",
        variant: "destructive",
      })
      return
    }

    try {
      const newClient: Client = {
        id: `client-${Date.now()}`,
        name: newClientName,
      }

      await saveClient(newClient)
      setNewClientName("")
      setIsAddDialogOpen(false)
      toast({
        title: "Success",
        description: "Client added successfully",
      })
      
      // Refresh the page
      router.refresh()
    } catch (error) {
      console.error("Error adding client:", error)
      toast({
        title: "Error",
        description: "Failed to add client",
        variant: "destructive",
      })
    }
  }
  
  const handleCloseDialog = () => {
    setIsEditDialogOpen(false)
    setIsAddDialogOpen(false)
    // Clear URL parameters
    router.push('/dashboard/clients')
  }
  
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="space-y-1">
          <h1 className="text-3xl font-bold">Clients</h1>
          <p className="text-muted-foreground">
            Manage your clients and their associated brands
          </p>
        </div>
        <Button onClick={() => setIsAddDialogOpen(true)}>
          <Plus className="mr-2 h-4 w-4" />
          Add Client
        </Button>
      </div>
      
      <ClientList hideActions={true} />
      
      {/* Add Client Dialog */}
      <Dialog open={isAddDialogOpen} onOpenChange={handleCloseDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Add Client</DialogTitle>
            <DialogDescription>Add a new client to your organization</DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-2">
            <div className="space-y-2">
              <Label htmlFor="clientName">Client Name</Label>
              <Input
                id="clientName"
                placeholder="Enter client name"
                value={newClientName}
                onChange={(e) => setNewClientName(e.target.value)}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={handleCloseDialog}>
              Cancel
            </Button>
            <Button onClick={handleAddClient}>Add Client</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      
      {/* Edit Client Dialog */}
      <Dialog open={isEditDialogOpen} onOpenChange={handleCloseDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Edit Client</DialogTitle>
            <DialogDescription>Update client information</DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-2">
            <div className="space-y-2">
              <Label htmlFor="editClientName">Client Name</Label>
              <Input
                id="editClientName"
                placeholder="Enter client name"
                value={currentClient?.name || ""}
                onChange={(e) => setCurrentClient(currentClient ? { ...currentClient, name: e.target.value } : null)}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={handleCloseDialog}>
              Cancel
            </Button>
            <Button onClick={handleEditClient}>Update Client</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}

