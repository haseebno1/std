import Link from "next/link"
import { TemplateList } from "@/components/templates/template-list"
import { Button } from "@/components/ui/button"
import { Plus } from "lucide-react"

export default function TemplatesPage() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Templates</h1>
          <p className="text-muted-foreground">
            Manage your ID card templates for different clients and brands.
          </p>
        </div>
        <Button asChild>
          <Link href="/dashboard/templates/new">
            <Plus className="mr-2 h-4 w-4" />
            Add Template
          </Link>
        </Button>
      </div>
      <TemplateList hideActions={true} />
    </div>
  )
}

