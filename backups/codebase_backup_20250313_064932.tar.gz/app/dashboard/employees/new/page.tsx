import { EmployeeForm } from "@/components/employees/employee-form"

export default function NewEmployeePage() {
  return <EmployeeForm />
}

