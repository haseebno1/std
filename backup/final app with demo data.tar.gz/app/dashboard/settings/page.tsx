import { SettingsForm } from "@/components/settings/settings-form"

export default function SettingsPage() {
  return <SettingsForm />
}

